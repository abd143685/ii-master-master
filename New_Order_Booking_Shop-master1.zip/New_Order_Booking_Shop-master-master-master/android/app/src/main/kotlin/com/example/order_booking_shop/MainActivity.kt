package com.aafdev.my_loc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
